/* =========================================================
 *
 * Strip Light Controller
 * By Mark Hastings
 *
 * 05/27/2013  v1.0  Mark Hastings   Initial working version
 * 09/04/2013  v1.3  Mark Hastings   Add more features and color lookup.
 * 12/02/2013  v1.6  Mark Hastings   Added a couple more functions.
 *
 * This file contains the functions required to control each
 * lighting control channel.
 *
 * =========================================================
*/

#include <project.h>
#include "cytypes.h"
#include "stdlib.h"
#include "cyfitter.h"
#include "LEDs.h"
#include "LEDs_fonts.h"

uint8  LEDs_initvar = 0;

#if(LEDs_MEMORY_TYPE == LEDs_MEMORY_RGB)
uint32  LEDs_ledArray[LEDs_ARRAY_ROWS][LEDs_ARRAY_COLS];
#else
uint8   LEDs_ledArray[LEDs_ARRAY_ROWS][LEDs_ARRAY_COLS];
#endif

uint32  LEDs_ledIndex = 0;  
uint32  LEDs_row = 0;
uint32  LEDs_refreshComplete;

uint32  LEDs_DimMask;
uint32  LEDs_DimShift;


#if(LEDs_CHIP == LEDs_CHIP_WS2812)
const uint32 LEDs_CLUT[ ] = {
//xxBBRRGG (WS2812)
//     (24)   [ Index = 0 ]
0x0000FFFF,  // 0 Yellow
0x0000CCFF,
0x000099FF,
0x000033FF,
0x000000FF,  // 5  Green
0x006600B3,
0x00990099, 
0x00B30066, 
0x00CC0033,  // 9 Blue
0x00B31919, 
0x00993300, 
0x00994000, 
0x00996600, 
0x00999900, 
0x0099CC00, 
0x0066E600, 
0x0000FF00, 
0x0000FF33, 
0x0000FF66, 
0x0000FF80, 
0x0000FF99,  // 20 Orange
0x0000FFB2, 
0x0000FFCC, 
0x0000FFE5,
// #24

//xxBBRRGG  (64)  [ Index = 24 ]
0x00000000, 0x00550000, 0x00AA0000, 0x00FF0000,  // 0, Black,  LtBlue, MBlue, Blue
0x00000055, 0x00550055, 0x00AA0055, 0x00FF0055,  // 4, LtGreen
0x000000AA, 0x005500AA, 0x00AA00AA, 0x00FF00AA,  // 8, MGreen
0x000000FF, 0x005500FF, 0x00AA00FF, 0x00FF00FF,  // 12 Green

0x00005500, 0x00555500, 0x00AA5500, 0x00FF5500,  // 16, LtRed
0x00005555, 0x00555555, 0x00AA5555, 0x00FF5555,  // 20, LtYellow
0x000055AA, 0x005555AA, 0x00AA55AA, 0x00FF55AA,  // 24, 
0x000055FF, 0x005555FF, 0x00AA55FF, 0x00FF55FF,  // 28,

0x0000AA00, 0x0055AA00, 0x00AAAA00, 0x00FFAA00,  // 32, MRed
0x0000AA55, 0x0055AA55, 0x00AAAA55, 0x00FFAA55,  // 36, 
0x0000AAAA, 0x0055AAAA, 0x00AAAAAA, 0x00FFAAAA,  // 55, 
0x0000AAFF, 0x0055AAFF, 0x00AAAAFF, 0x00FFAAFF,  // 44, 

0x0000FF00, 0x0055FF00, 0x00AAFF00, 0x00FFFF00,  // 48, Red, ??, ??, Magenta
0x0000FF55, 0x0055FF55, 0x00AAFF55, 0x00FFFF55,  // 52,
0x0000FFAA, 0x0055FFAA, 0x00AAFFAA, 0x00FFFFAA,  // 56,
0x0000FFFF, 0x0055FFFF, 0x00AAFFFF, 0x00FFFFFF,  // 60, Yellow,??, ??, White

// Misc ( 16 )  [ Index = 88 ]
0x000080FF,  // SPRING_GREEN
0x008000FF,  // TURQUOSE
0x00FF00FF,  // CYAN
0x00FF0080,  // OCEAN
0x00FF8000,  // VIOLET
0x0080FF00,  // RASPBERRY
0x000000FF,  // GREEN
0x00202020,  // DIM WHITE
0x00200000,  // DIM BLUE
0x10000000,  // INVISIBLE
0x00000000,  // Spare
0x00000000,  // Spare
0x00000000,  // Spare
0x00000000,  // Spare
0x00000000,  // Spare
0x00000000,  // Spare

// Temperture Color Blue to Red (16) [ Index = 104 ]
0x00FF0000, 0x00F01000, 0x00E02000, 0x00D03000,
0x00C04000, 0x00B05000, 0x00A06000, 0x00907000,
0x00808000, 0x00709000, 0x0060A000, 0x0050B000,
0x0040C000, 0x0030D000, 0x0020E000, 0x0000FF00
};
#else  //xxBBGGRR (WS2811)
const uint32 LEDs_CLUT[ ] = {
//     (24)   [ Index = 0 ]
0x0000FFFF,  // 0 Yellow
0x0000FFCC,
0x0000FF99,
0x0000FF33,
0x0000FF00,  // 5  Green
0x0066B300,
0x00999900, 
0x00B36600, 
0x00CC3300,  // 9 Blue
0x00B31919, 
0x00990033, 
0x00990040, 
0x00990066, 
0x00990099, 
0x009900CC, 
0x006600E6, 
0x000000FF, 
0x000033FF, 
0x000066FF, 
0x000080FF, 
0x000099FF,  // 20 Orange
0x0000B2FF, 
0x0000CCFF, 
0x0000E5FF,
// #24

//xxBBRRGG  (64)  [ Index = 24 ]
0x00000000, 0x00550000, 0x00AA0000, 0x00FF0000,  // 0, Black,  LtBlue, MBlue, Blue
0x00005500, 0x00555500, 0x00AA5500, 0x00FF5500,  // 4, LtGreen
0x0000AA00, 0x0055AA00, 0x00AAAA00, 0x00FFAA00,  // 8, MGreen
0x0000FF00, 0x0055FF00, 0x00AAFF00, 0x00FFFF00,  // 12 Green

0x00000055, 0x00550055, 0x00AA0055, 0x00FF0055,  // 16, LtRed
0x00005555, 0x00555555, 0x00AA5555, 0x00FF5555,  // 20, LtYellow
0x0000AA55, 0x0055AA55, 0x00AAAA55, 0x00FFAA55,  // 24, 
0x0000FF55, 0x0055FF55, 0x00AAFF55, 0x00FFFF55,  // 28,

0x000000AA, 0x005500AA, 0x00AA00AA, 0x00FF00AA,  // 32, MRed
0x000055AA, 0x005555AA, 0x00AA55AA, 0x00FF55AA,  // 36, 
0x0000AAAA, 0x0055AAAA, 0x00AAAAAA, 0x00FFAAAA,  // 55, 
0x0000FFAA, 0x0055FFAA, 0x00AAFFAA, 0x00FFFFAA,  // 44, 

0x000000FF, 0x005500FF, 0x00AA00FF, 0x00F00FFF,  // 48, Red, ??, ??, Magenta
0x000055FF, 0x005555FF, 0x00AA55FF, 0x00FF55FF,  // 52,
0x0000AAFF, 0x0055AAFF, 0x00AAAAFF, 0x00FFAAFF,  // 56,
0x0000FFFF, 0x0055FFFF, 0x00AAFFFF, 0x00FFFFFF,  // 60, Yellow,??, ??, White

// Misc ( 16 )  [ Index = 88 ]
0x0000FF80,  // SPRING_GREEN
0x0080FF00,  // TURQUOSE
0x00FFFF00,  // CYAN
0x00FF8000,  // OCEAN
0x00FF0080,  // VIOLET
0x008000FF,  // RASPBERRY
0x0000FF00,  // GREEN
0x00202020,  // DIM WHITE
0x00200000,  // DIM BLUE
0x10000000,  // INVISIBLE
0x00000000,  // Spare
0x00000000,  // Spare
0x00000000,  // Spare
0x00000000,  // Spare
0x00000000,  // Spare
0x00000000,  // Spare

// Temperture Color Blue to Red (16) [ Index = 104 ]
0x00FF0000, 0x00F00010, 0x00E00020, 0x00D00030,
0x00C00040, 0x00B00050, 0x00A00060, 0x00900070,
0x00800080, 0x00700090, 0x006000A0, 0x005000B0,
0x004000C0, 0x003000D0, 0x002000E0, 0x000000FF
};
#endif



/*******************************************************************************
* Function Name: LEDs_Start
********************************************************************************
* Summary:
*  Initialize the hardware. 
*
* Parameters:  
*  void  
*
* Return: 
*  void
*
*******************************************************************************/
void LEDs_Start()
{
    extern uint8 LEDs_initvar;
    extern uint32 LEDs_refreshComplete;

    LEDs_ACTL0_REG = LEDs_DISABLE_FIFO;
    
    LEDs_Period   = LEDs_PERIOD-1;
    LEDs_Compare0 = LEDs_DATA_ZERO;
    LEDs_Compare1 = LEDs_DATA_ONE;
    
    LEDs_CONTROL = LEDs_ENABLE;
    LEDs_MemClear(LEDs_OFF);
    LEDs_CONTROL = LEDs_DISABLE;
    
    LEDs_SetFont( LEDs_FONT_5X7);
    
    /* Set no dimming, full brightness */
    LEDs_Dim(0); 

    
    if(LEDs_initvar == 0)
    {

        LEDs_initvar = 1;
 
         /* Start and set interrupt vector */

#if(LEDs_TRANSFER == LEDs_TRANSFER_ISR)
       {
           LEDs_cisr_StartEx(LEDs_CISR);
		   LEDs_fisr_StartEx(LEDs_FISR);
       }
#endif       
       if(LEDs_TRANSFER == LEDs_TRANSFER_FIRMWARE)
       {
           LEDs_CONTROL = LEDs_ENABLE;    
       }
    }
    LEDs_refreshComplete = 1;
}


/*******************************************************************************
* Function Name: LEDs_Trigger
********************************************************************************
* Summary:
*   Update the LEDs with graphics memory.
*
* Parameters:  
*  void  
*
* Return: 
*  void
*
*******************************************************************************/
void LEDs_Trigger(uint32 rst)
{
    uint32 color;
    
    if(rst) 
    {
        LEDs_row = 0;  /* Reset the row */
        LEDs_Channel = 0;
    }
    
    #if(LEDs_MEMORY_TYPE == LEDs_MEMORY_RGB)
       color = LEDs_ledArray[LEDs_row][0];
    #else  /* Else use lookup table */
       color = LEDs_CLUT[ (LEDs_ledArray[LEDs_row][0]) ];
    #endif
    
     color = (color >> LEDs_DimShift) & LEDs_DimMask;
     
    LEDs_DATA = (uint8)(color & 0x000000FF);  // Write Red
    color = color >> 8;
    LEDs_DATA = (uint8)(color & 0x000000FF);  // Write green
    color = color >> 8;
    LEDs_DATA = (uint8)(color & 0x000000FF);  // Write green
    
    LEDs_ledIndex = 1;
 //   LEDs_CONTROL = LEDs_ENABLE | LEDs_FIFO_IRQ_EN; 
	
	LEDs_CONTROL = LEDs_ENABLE | LEDs_XFRCMPT_IRQ_EN | LEDs_FIFO_IRQ_EN; 
    LEDs_refreshComplete = 0;
}

/*******************************************************************************
* Function Name: LEDs_Ready
********************************************************************************
* Summary:
*  Checks to see if transfer is complete.
*
* Parameters:  
*  none  
*
* Return: 
*  Zero if not complete, non-zero if transfer complete.
*
*******************************************************************************/
uint32 LEDs_Ready(void)
{
    if(LEDs_refreshComplete )
    {
        LEDs_CONTROL = LEDs_DISABLE;
        return((uint32)1);
    }
    else
    {
         return((uint32)0);
    }
}


/*******************************************************************************
* Function Name: LEDs_Stop
********************************************************************************
* Summary:
*  Stop all transfers.
*
* Parameters:  
*  None 
*
* Return: 
*  void
*
*******************************************************************************/
void LEDs_Stop()
{

    LEDs_CONTROL = LEDs_DISABLE;
}


/*******************************************************************************
* Function Name: LEDs_ColorInc
********************************************************************************
* Summary:
*  Increment color throught the color lookup table.
*
* Parameters:  
*  uint32 incValue: Increment through color table by incValue. 
*
* Return: Color at next location.
*  
*
*******************************************************************************/
uint32 LEDs_ColorInc(uint32 incValue)
{
    uint32 color;
    extern const uint32 LEDs_CLUT[];
    static uint32 colorIndex = 0;
    
    colorIndex += incValue;
    colorIndex = colorIndex % LEDs_COLOR_WHEEL_SIZE;

    #if(LEDs_MEMORY_TYPE == LEDs_MEMORY_RGB)
       color = LEDs_CLUT[ colorIndex ];
    #else
        color = colorIndex;
    #endif


    return(color);
}
/*****************************************************************************
* Function Name: LEDs_FISR
******************************************************************************
*
* Summary:
*  Interrupt service handler for data transfer for each LED 
*
* Parameters:  
*  void
*
* Return: 
*  void 
*
* Reentrant: 
*  No
*
*****************************************************************************/
CY_ISR( LEDs_FISR)
{
    extern uint32  LEDs_DimMask;
    extern uint32  LEDs_DimShift;
    uint32 static color;

    if(LEDs_ledIndex < LEDs_ARRAY_COLS)
    {
        #if(LEDs_MEMORY_TYPE == LEDs_MEMORY_RGB)
            color = LEDs_ledArray[LEDs_row][LEDs_ledIndex++];
        #else  /* Else use lookup table */
            color = LEDs_CLUT[ (LEDs_ledArray[LEDs_row][LEDs_ledIndex++]) ];
        #endif

        color = (color >> LEDs_DimShift) & LEDs_DimMask;  

        LEDs_DATA = (uint8)(color & 0x000000FF);  // Write Green
        color = color >> 8;
        LEDs_DATA = (uint8)(color & 0x000000FF);  // Write Red
        color = color >> 8;
        LEDs_DATA = (uint8)(color & 0x000000FF);  // Write Blue
    }
    else 
    {
         LEDs_CONTROL = LEDs_ENABLE | LEDs_XFRCMPT_IRQ_EN; 
    }

}

/*****************************************************************************
* Function Name: LEDs_CISR
******************************************************************************
*
* Summary:
*  Interrupt service handler after each row is complete.
*
* Parameters:  
*  void
*
* Return: 
*  void 
*
* Reentrant: 
*  No
*
*****************************************************************************/
CY_ISR( LEDs_CISR)
{
    extern uint32  LEDs_DimMask;
    extern uint32  LEDs_DimShift;
    uint32 static color;
    extern uint32 LEDs_refreshComplete;

	LEDs_CONTROL = LEDs_ENABLE |LEDs_NEXT_ROW;
    LEDs_row++;
    if( LEDs_row < LEDs_ARRAY_ROWS)  /* More Rows to do  */
    {
        LEDs_Channel = LEDs_row;  

		#if(LEDs_MEMORY_TYPE == LEDs_MEMORY_RGB)
             color = LEDs_ledArray[LEDs_row][0];
        #else  /* Else use lookup table */
             color = LEDs_CLUT[ (LEDs_ledArray[LEDs_row][0]) ];
        #endif

        color = (color >> LEDs_DimShift) & LEDs_DimMask;
 
        LEDs_DATA = (uint8)(color & 0x000000FF);  /* Write Red   */
        color = color >> 8;
        LEDs_DATA = (uint8)(color & 0x000000FF);  /* Write green */
        color = color >> 8;
        LEDs_DATA = (uint8)(color & 0x000000FF);  /* Write green */

        LEDs_ledIndex = 1;
		LEDs_CONTROL = LEDs_ENABLE | LEDs_FIFO_IRQ_EN; 
		
    }
    else
    {
        LEDs_refreshComplete = 1u;
    }
  
}


/*******************************************************************************
* Function Name: LEDs_DisplayClear
********************************************************************************
* Summary:
*   Clear memory with a given value and update the display.
*
* Parameters:  
*  uint32 color: Color to clear display. 
*
* Return: 
*  void
*
*******************************************************************************/
void LEDs_DisplayClear(uint32 color)
{   
    LEDs_MemClear(color);
    LEDs_Trigger(1);
}

/*******************************************************************************
* Function Name: LEDs_MemClear
********************************************************************************
* Summary:
*   Clear LED memory with given color, but do not update display.
*
* Parameters:  
*  uint32 color: Color to clear display.  
*
* Return: 
*  void
*
*******************************************************************************/
void LEDs_MemClear(uint32 color)
{
    uint32  row, col;
    
    for(row=0; row < LEDs_ARRAY_ROWS; row++)
    {
        for(col=0; col < LEDs_ARRAY_COLS; col++)
        {
            LEDs_ledArray[row][col] = color;
            #if(LEDs_MEMORY_TYPE == LEDs_MEMORY_RGB)
                LEDs_ledArray[row][col] = color;
            #else  /* Else use lookup table */
                 LEDs_ledArray[row][col] = (uint8)color;
            #endif
        }
    }
}



/*******************************************************************************
* Function Name: LEDs_WriteColor
********************************************************************************
* Summary:
*   Write given color directly to output register.
*
* Parameters:  
*  uint32 color: Color to write to display. 
*
* Return: 
*  void
*
*******************************************************************************/
void LEDs_WriteColor(uint32 color)
{
    while( (LEDs_STATUS & LEDs_FIFO_EMPTY) == 0); 

    LEDs_DATA = (uint8)(color & 0x000000FF);  // Write Green
    color = color >> 8;
    LEDs_DATA = (uint8)(color & 0x000000FF);  // Write Red
    color = color >> 8;
    LEDs_DATA = (uint8)(color & 0x000000FF);  // Write Blue
}


/*******************************************************************************
* Function Name: LEDs_Pixel
********************************************************************************
*
* Summary:
*  Draw Pixel  
*
* Parameters:  
*  x,y:    Location to draw the pixel
*  color:  Color of the pixel
*
* Return: 
*  None 
*******************************************************************************/
void LEDs_Pixel(int32 x, int32 y, uint32 color)
{

	if((x >= LEDs_MIN_X) && (y >= LEDs_MIN_Y) && (x <= LEDs_MAX_X) && (y <= LEDs_MAX_Y))
    {

    #if(LEDs_MEMORY_TYPE == LEDs_MEMORY_RGB)
       LEDs_ledArray[y][x] = color;
    #else  /* Else use lookup table */
       LEDs_ledArray[y][x] = (uint8)color;
    #endif
    }
  
}

/*******************************************************************************
* Function Name: LEDs_GetPixel
********************************************************************************
*
* Summary:
*  Get Pixel Color  
*
* Parameters:  
*  x,y:    Location to get pixel color
*
* Return: 
*  None 
*******************************************************************************/
uint32 LEDs_GetPixel(int32 x, int32 y)
{
    uint32 color;
    if((x>=0) && (y>=0) && (x < LEDs_ARRAY_COLS) && (y < LEDs_ARRAY_ROWS))
    {
    #if(LEDs_MEMORY_TYPE == LEDs_MEMORY_RGB)
       color = LEDs_ledArray[y][x];
    #else  /* Else use lookup table */
       color = (uint32)LEDs_ledArray[y][x];
    #endif
    }
    return(color);
}

/*******************************************************************************
* Function Name: LEDs_DrawCircle
********************************************************************************
*
* Summary:
*  Draw a circle on the display given a start point and radius.  
*
*  This code uses Bresenham's Circle Algorithm. 
*
* Parameters:  
*  x0, y0: Center of circle
*  radius: Radius of circle
*  color:  Color of circle
*
* Return: 
*  None 
*  
*******************************************************************************/
void LEDs_DrawCircle (int32 x0, int32 y0, int32 radius, uint32 color)
{
	int32 f = 1 - radius;
	int32 ddF_x = 0;
	int32 ddF_y = -2 * radius;
	int32 x = 0;
	int32 y = radius;

	LEDs_Pixel(x0, y0 + radius, color);
	LEDs_Pixel(x0, y0 - radius, color);
	LEDs_Pixel( x0 + radius, y0, color);
	LEDs_Pixel( x0 - radius, y0, color);

	while(x < y)
	{
		if(f >= 0)
		{
			y--;
			ddF_y += 2;
			f += ddF_y;
		}
		x++;
		ddF_x += 2;
		f += ddF_x + 1;

		LEDs_Pixel(x0 + x, y0 + y, color);
		LEDs_Pixel(x0 - x, y0 + y, color);
		LEDs_Pixel( x0 + x, y0 - y, color);
		LEDs_Pixel( x0 - x, y0 - y, color);
		LEDs_Pixel( x0 + y, y0 + x, color);
		LEDs_Pixel( x0 - y, y0 + x, color);
		LEDs_Pixel( x0 + y, y0 - x, color);
		LEDs_Pixel( x0 - y, y0 - x, color);
	}
}


/*******************************************************************************
* Function Name: LEDs_DrawLine
********************************************************************************
*
* Summary:
*  Draw a line on the display.  
*
* Parameters:  
*  x0, y0:  The beginning endpoint
*  x1, y1:  The end endpoint.
*  color:   Color of the line.
*
* Return: 
*  None 
*  
*******************************************************************************/
void LEDs_DrawLine(int32 x0, int32 y0, int32 x1, int32 y1, uint32 color)
{
	int32 dy = y1 - y0; /* Difference between y0 and y1 */
	int32 dx = x1 - x0; /* Difference between x0 and x1 */
	int32 stepx, stepy;

	if (dy < 0)
	{
		dy = -dy;
		stepy = -1;
	}
	else
	{
		stepy = 1;
	}

	if (dx < 0)
	{
		dx = -dx;
		stepx = -1;
	}
	else
	{
		stepx = 1;
	}

	dy <<= 1; /* dy is now 2*dy  */
	dx <<= 1; /* dx is now 2*dx  */
	LEDs_Pixel(x0, y0, color);

	if (dx > dy) 
	{
		int fraction = dy - (dx >> 1);
		while (x0 != x1)
		{
			if (fraction >= 0)
			{
				y0 += stepy;
				fraction -= dx;
			}
			x0 += stepx;
			fraction += dy;
			LEDs_Pixel(x0, y0, color);
		}
	}
	else
	{
		int fraction = dx - (dy >> 1);
		while (y0 != y1)
		{
			if (fraction >= 0)
			{
				x0 += stepx;
				fraction -= dy;
			}
			y0 += stepy;
			fraction += dx;
			LEDs_Pixel( x0, y0, color);
		}
	}
}

/*******************************************************************************
* Function Name: LEDs_DrawRect
********************************************************************************
*
* Summary:
*  Draw a rectangle, filled or not.  
*
* Parameters:  
*  x0, y0:  The upper lefthand corner.
*  x1, y1:  The lower right corner.
*  fill:    Non-Zero if retangle is to be filled.
*  color:   Color for rectangle, border and fill.
*
* Return: 
*  None 
*  
*******************************************************************************/
void LEDs_DrawRect(int32 x0, int32 y0, int32 x1, int32 y1, int32 fill, uint32 color)
{	
     int xDiff;
	/* Check if the rectangle is to be filled    */
	if (fill != 0)
	{	
        /* Find the difference between the x vars */
		if(x0 > x1)
		{
			xDiff = x0 - x1; 
		}
		else
		{
			xDiff = x1 - x0;
		}
	
	    /* Fill it with lines  */
		while(xDiff >= 0)
		{
			LEDs_DrawLine(x0, y0, x0, y1, color);
		
			if(x0 > x1)
				x0--;
			else
				x0++;
		
			xDiff--;
		}

	}
	else 
	{
		/* Draw the four sides of the rectangle */
		LEDs_DrawLine(x0, y0, x1, y0, color);
		LEDs_DrawLine(x0, y1, x1, y1, color);
		LEDs_DrawLine(x0, y0, x0, y1, color);
		LEDs_DrawLine(x1, y0, x1, y1, color);
	}
}

/*******************************************************************************
* Function Name: LEDs_Dim
********************************************************************************
*
* Summary:
*  Dim all output by a specific level (0,1,2,3,4)  
*
* Parameters:  
*  dimLevel:  Dim level 1 to 4, 0 => No dimming.
*
* Return: 
*  None 
*  
*******************************************************************************/
void LEDs_Dim(uint32 dimLevel) 
{
extern uint32  LEDs_DimMask;
extern uint32  LEDs_DimShift;

    switch(dimLevel)
    {
       case 1:  // 1/2 bright
           LEDs_DimMask = 0x007F7F7F;
           LEDs_DimShift = 1;
           break;
           
       case 2:
           LEDs_DimMask = 0x003F3F3F;
           LEDs_DimShift = 2;
           break;
           
       case 3:
           LEDs_DimMask = 0x001F1F1F;
           LEDs_DimShift = 3;
           break;
           
       case 4:
           LEDs_DimMask = 0x000F0F0F;
           LEDs_DimShift = 4;
           break;
           
       default:
           LEDs_DimMask = 0x00FFFFFF;
           LEDs_DimShift = 0;
           break;
        
    }
}

void LEDs_bplot( int32 x, int32 y, uint8 * bitMap, int32 update)
{
    int32 dx, dy;
    int32 aindex = 0;
    int32 maxX, maxY;

    maxX = x + (int32)bitMap[aindex++];
    maxY = y  + (int32)bitMap[aindex++];

	for(dy = y; dy < maxY; dy++)
    {
		for(dx = x; dx < maxX; dx++)
        {
            LEDs_Pixel(dx, dy, bitMap[aindex++]);
        }
    }
	if(update) LEDs_Trigger(1);
}

/* [] END OF FILE */

/* ========================================
 *
 * Strip Light Controller
 * By Mark Hastings
 *
 * 05/27/2013  v1.0  Mark Hastings   Initial working version
 *
 * ========================================
*/

#if (!defined(CY_SLIGHTS_LEDs_H))
#define CY_SLIGHTS_LEDs_H

#include "cytypes.h"
#include "cyfitter.h"

/* Function Prototypes */
void   LEDs_Start(void);
void   LEDs_Stop(void);
void   LEDs_WriteColor(uint32 color);
void   LEDs_DisplayClear(uint32 color);
void   LEDs_MemClear(uint32 color);
void   LEDs_Trigger(uint32 rst);
uint32 LEDs_Ready(void);

void   LEDs_DrawRect(int32 x0, int32 y0, int32 x1, int32 y1, int32 fill, uint32 color);
void   LEDs_DrawLine(int32 x0, int32 y0, int32 x1, int32 y1, uint32 color);
void   LEDs_DrawCircle (int32 x0, int32 y0, int32 radius, uint32 color);
void   LEDs_Pixel(int32 x, int32 y, uint32 color);
uint32 LEDs_GetPixel(int32 x, int32 y);
uint32 LEDs_ColorInc(uint32 incValue);
void   LEDs_Dim(uint32 dimLevel); 

#define LEDs_DimLevel_0   0
#define LEDs_DimLevel_1   1
#define LEDs_DimLevel_2   2
#define LEDs_DimLevel_3   3
#define LEDs_DimLevel_4   4




#define LEDs_CIRQ_Enable() CyIntEnable(LEDs_CIRQ__INTC_NUMBER ); 
#define LEDs_CIRQ_Disable() CyIntDisable(LEDs_CIRQ__INTC_NUMBER );
CY_ISR_PROTO(LEDs_CISR);

#define LEDs_FIRQ_Enable() CyIntEnable(LEDs_FIRQ__INTC_NUMBER ); 
#define LEDs_FIRQ_Disable() CyIntDisable(LEDs_FIRQ__INTC_NUMBER );
CY_ISR_PROTO(LEDs_FISR);

/* Register Definitions */
#define LEDs_DATA         (*(reg8 *) LEDs_B_WS2811_dshifter_u0__F0_REG)
#define LEDs_DATA_PTR     ((reg8 *)  LEDs_B_WS2811_dshifter_u0__F0_REG)

#define LEDs_CONTROL      (*(reg8 *) LEDs_B_WS2811_ctrl__CONTROL_REG)
#define LEDs_STATUS       (*(reg8 *) LEDs_B_WS2811_StatusReg__STATUS_REG)

#define LEDs_Period       (*(reg8 *) LEDs_B_WS2811_pwm8_u0__F0_REG)
#define LEDs_Period_PTR   ((reg8 *)  LEDs_B_WS2811_pwm8_u0__F0_REG)

#define LEDs_Compare0     (*(reg8 *) LEDs_B_WS2811_pwm8_u0__D0_REG)
#define LEDs_Compare1     (*(reg8 *) LEDs_B_WS2811_pwm8_u0__D1_REG)

#define LEDs_Period2      (*(reg8 *) LEDs_B_WS2811_pwm8_u0__F1_REG)
#define LEDs_Period2_PTR  ((reg8 *)  LEDs_B_WS2811_pwm8_u0__F1_REG)

#define LEDs_ACTL0_REG    (*(reg8 *) LEDs_B_WS2811_pwm8_u0__DP_AUX_CTL_REG)
#define LEDs_DISABLE_FIFO  0x03


#define LEDs_Channel      (*(reg8 *) LEDs_StringSel_Sync_ctrl_reg__CONTROL_REG)
#define LEDs_Channel_PTR  ((reg8 *)  LEDs_StringSel_Sync_ctrl_reg__CONTROL_REG)



/* Status Register Constants  */
#define LEDs_FIFO_EMPTY       0x01
#define LEDs_FIFO_NOT_FULL    0x02
#define LEDs_STATUS_ENABLE    0x80
#define LEDs_STATUS_XFER_CMPT 0x40

/* Control Register Constants */
#define LEDs_ENABLE         0x01
#define LEDs_DISABLE        0x00
#define LEDs_RESTART        0x02
#define LEDs_CNTL           0x04
#define LEDs_FIFO_IRQ_EN    0x08
#define LEDs_XFRCMPT_IRQ_EN 0x10
#define LEDs_ALL_IRQ_EN     0x18
#define LEDs_NEXT_ROW       0x20

#define LEDs_TRANSFER           1
#define LEDs_TRANSFER_FIRMWARE  0
#define LEDs_TRANSFER_ISR       1
#define LEDs_TRANSFER_DMA       2

#define LEDs_SPEED        
#define LEDs_SPEED_400KHZ 0
#define LEDs_SPEED_800KHZ 1

#define LEDs_MEMORY_TYPE  1
#define LEDs_MEMORY_RGB   0
#define LEDs_MEMORY_LUT   1

#if (CY_PSOC3 || CY_PSOC5LP)
    #define  LEDs_PERIOD     ((BCLK__BUS_CLK__KHZ)/800)
#elif (CY_PSOC4)
    #define  LEDs_PERIOD     ((CYDEV_BCLK__HFCLK__KHZ)/800)
#endif /* CY_PSOC5A */
        

#define  LEDs_DATA_ZERO  ((LEDs_PERIOD * 20)/25) 
#define  LEDs_DATA_ONE   ((LEDs_PERIOD * 12)/25) 


#if (LEDs_SPEED_800KHZ)
    #define LEDs_BYTE_TIME_US 10u
    #define LEDs_WORD_TIME_US 30u
#else
    #define LEDs_BYTE_TIME_US 20u
    #define LEDs_WORD_TIME_US 60u
#endif

#define LEDs_COLUMNS     12
#define LEDs_ROWS        1
#define LEDs_TOTAL_LEDS   (LEDs_COLUMNS*LEDs_ROWS)

#define LEDs_ARRAY_COLS  (int32)(12)
#define LEDs_ARRAY_ROWS  (int32)(1)
#define LEDs_CHIP        (2)
#define LEDs_CHIP_WS2811 1
#define LEDs_CHIP_WS2812 2

#define LEDs_MIN_X        (int32)0u
#define LEDs_MAX_X        (int32)(LEDs_COLUMNS - 1)
#define LEDs_MIN_Y        (int32)0u
#define LEDs_MAX_Y        (int32)(LEDs_ROWS - 1)

//#define LEDs_RBCOLORS     48
#define LEDs_COLOR_WHEEL_SIZE  24

#if(LEDs_CHIP == LEDs_CHIP_WS2812)
#define LEDs_RED_MASK   0x0000FF00
#define LEDs_GREEN_MASK 0x000000FF
#define LEDs_BLUE_MASK  0x00FF0000
#else
#define LEDs_RED_MASK   0x000000FF
#define LEDs_GREEN_MASK 0x0000FF00
#define LEDs_BLUE_MASK  0x00FF0000	
#endif

#if(LEDs_MEMORY_TYPE == LEDs_MEMORY_RGB)
   #define LEDs_getColor( a ) LEDs_CLUT[a]
#else  /* Else use lookup table */
   #define LEDs_getColor( a ) a
#endif


#define LEDs_CWHEEL_SIZE 24
#define LEDs_YELLOW      LEDs_getColor(1)
#define LEDs_GREEN       LEDs_getColor((70 + LEDs_CWHEEL_SIZE))
#define LEDs_ORANGE      LEDs_getColor(20)
#define LEDs_BLACK       LEDs_getColor((0 + LEDs_CWHEEL_SIZE))
#define LEDs_OFF         LEDs_getColor((0 + LEDs_CWHEEL_SIZE))
#define LEDs_LTBLUE      LEDs_getColor((1 + LEDs_CWHEEL_SIZE))
#define LEDs_MBLUE       LEDs_getColor((2 + LEDs_CWHEEL_SIZE))
#define LEDs_BLUE        LEDs_getColor((3 + LEDs_CWHEEL_SIZE))
#define LEDs_LTGREEN     LEDs_getColor((4 + LEDs_CWHEEL_SIZE))
#define LEDs_MGREEN      LEDs_getColor((8 + LEDs_CWHEEL_SIZE))
//#define LEDs_GREEN       (12 + LEDs_CWHEEL_SIZE) 
#define LEDs_LTRED       LEDs_getColor((16 + LEDs_CWHEEL_SIZE)) 
#define LEDs_LTYELLOW    LEDs_getColor((20 + LEDs_CWHEEL_SIZE))
#define LEDs_MGRED       LEDs_getColor((32 + LEDs_CWHEEL_SIZE)) 
#define LEDs_RED         LEDs_getColor((48 + LEDs_CWHEEL_SIZE)) 
#define LEDs_MAGENTA     LEDs_getColor((51 + LEDs_CWHEEL_SIZE))
#define LEDs_WHITE       LEDs_getColor((63 + LEDs_CWHEEL_SIZE)) 

#define LEDs_SPRING_GREEN LEDs_getColor((64 + LEDs_CWHEEL_SIZE)) 
#define LEDs_TURQUOSE    LEDs_getColor((65 + LEDs_CWHEEL_SIZE)) 
#define LEDs_CYAN        LEDs_getColor((66 + LEDs_CWHEEL_SIZE)) 
#define LEDs_OCEAN       LEDs_getColor((67 + LEDs_CWHEEL_SIZE)) 
#define LEDs_VIOLET      LEDs_getColor((68 + LEDs_CWHEEL_SIZE)) 
#define LEDs_RASPBERRY   LEDs_getColor((69 + LEDs_CWHEEL_SIZE)) 
#define LEDs_DIM_WHITE   LEDs_getColor((71 + LEDs_CWHEEL_SIZE)) 
#define LEDs_DIM_BLUE    LEDs_getColor((72 + LEDs_CWHEEL_SIZE)) 
#define LEDs_INVISIBLE   LEDs_getColor((73 + LEDs_CWHEEL_SIZE))

#define LEDs_COLD_TEMP   LEDs_getColor((80 + LEDs_CWHEEL_SIZE)) 
#define LEDs_HOT_TEMP    LEDs_getColor((95 + LEDs_CWHEEL_SIZE)) 

#define LEDs_CLUT_SIZE  (96 + LEDs_CWHEEL_SIZE)

#define LEDs_RESET_DELAY_US  55

#endif  /* CY_SLIGHTS_LEDs_H */

//[] END OF FILE

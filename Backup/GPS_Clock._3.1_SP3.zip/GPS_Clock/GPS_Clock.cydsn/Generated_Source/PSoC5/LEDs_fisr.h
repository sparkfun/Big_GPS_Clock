/*******************************************************************************
* File Name: LEDs_fisr.h
* Version 1.70
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_LEDs_fisr_H)
#define CY_ISR_LEDs_fisr_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void LEDs_fisr_Start(void);
void LEDs_fisr_StartEx(cyisraddress address);
void LEDs_fisr_Stop(void);

CY_ISR_PROTO(LEDs_fisr_Interrupt);

void LEDs_fisr_SetVector(cyisraddress address);
cyisraddress LEDs_fisr_GetVector(void);

void LEDs_fisr_SetPriority(uint8 priority);
uint8 LEDs_fisr_GetPriority(void);

void LEDs_fisr_Enable(void);
uint8 LEDs_fisr_GetState(void);
void LEDs_fisr_Disable(void);

void LEDs_fisr_SetPending(void);
void LEDs_fisr_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the LEDs_fisr ISR. */
#define LEDs_fisr_INTC_VECTOR            ((reg32 *) LEDs_fisr__INTC_VECT)

/* Address of the LEDs_fisr ISR priority. */
#define LEDs_fisr_INTC_PRIOR             ((reg8 *) LEDs_fisr__INTC_PRIOR_REG)

/* Priority of the LEDs_fisr interrupt. */
#define LEDs_fisr_INTC_PRIOR_NUMBER      LEDs_fisr__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable LEDs_fisr interrupt. */
#define LEDs_fisr_INTC_SET_EN            ((reg32 *) LEDs_fisr__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the LEDs_fisr interrupt. */
#define LEDs_fisr_INTC_CLR_EN            ((reg32 *) LEDs_fisr__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the LEDs_fisr interrupt state to pending. */
#define LEDs_fisr_INTC_SET_PD            ((reg32 *) LEDs_fisr__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the LEDs_fisr interrupt. */
#define LEDs_fisr_INTC_CLR_PD            ((reg32 *) LEDs_fisr__INTC_CLR_PD_REG)


#endif /* CY_ISR_LEDs_fisr_H */


/* [] END OF FILE */

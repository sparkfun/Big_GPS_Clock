/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/*  FONTS  */

#define LEDs_FONT_5X7  0

/* 5x7 Font */
//#define LEDs_Font5x7_COLS  5
//#define LEDs_Font5x7_ROWS  7
#define LEDs_Font5x7_XSIZE  5
#define LEDs_Font5x7_YSIZE  7
#define LEDs_Font5x7_OFFSET 32u
#define LEDs_COLORWHEEL_FONT  0x80000000
#define LEDs_TRANS_BG         0xFF000000


void LEDs_SetFont( uint32 font);
void LEDs_PutChar(int32 row, int32 col, uint8 theChar, uint32 fg, uint32 bg);
void LEDs_PrintString(int32 row, int32 col, char * theString, uint32 fg, uint32 bg);

//[] END OF FILE
